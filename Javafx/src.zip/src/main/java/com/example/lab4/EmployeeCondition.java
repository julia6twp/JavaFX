package com.example.lab4;

public enum EmployeeCondition {
    obecny,
    delegacja,
    chory,
    nieobecny
}
